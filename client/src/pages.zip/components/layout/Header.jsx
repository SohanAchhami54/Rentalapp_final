import { useState } from "react";
import { GiHamburgerMenu } from "react-icons/gi";
import { RxCross1 } from "react-icons/rx";
import { NavLink, useLocation } from "react-router-dom";
import { Button } from "../../shadcnui/button";
import { useAppcontext } from "../../context/AppContext";

  const Header = () => {
    const {setShowLogin,user,logout,isOwner,axios,setIsOwner}=useAppcontext();
    const [open,setOpen]=useState(false);
   // const [showLogin,setShowLogin]=useState(false);//setter function that will open the login form.
 
    const isOwnerPath=useLocation().pathname.startsWith('/owner'); //owner path.
    return (
      <header className="bg-neutral-200">
        {!isOwnerPath&&
        <nav className='flex justify-between px-2 md:justify-around p-3 font-medium'>
        <h1 className="text-2xl font-medium"><NavLink href='/'>RentalApp</NavLink></h1>
         {!open&&(
            <button className="md:hidden text-xl" onClick={()=>setOpen(true)}>
          <GiHamburgerMenu />
          </button>
        )}  
          <section className="hidden md:flex">
          <ul className='flex gap-10 justify-center items-center'>
          <NavLink to={'/'} ><li>Home</li> </NavLink> 
          <NavLink to={'/car'} ><li>Car</li></NavLink> 
          <NavLink to={'/mybooking'} > <li>My Booking</li> </NavLink> 

           <NavLink to={'/owner'} ><li>  Dashboard </li></NavLink>

           <div className="flex gap-2">
        <li><Button onClick={()=>user?logout:setShowLogin(true)}
         className="bg-black text-white"> <NavLink to={'/login'}>
          {user?'Logout':'Login'}
          </NavLink> </Button></li>
        <li><Button className="bg-black text-white"> <NavLink to={'/signup'} >SignUp</NavLink> </Button></li>
      {/* <li><Button className="bg-black text-white"> <NavLink to={'/logout'} >Logout</NavLink> </Button></li> */}
          </div>
           {/* <li><Button onClick={()=>setShowLogin(true)}>Login</Button></li> */}
            </ul>
          </section>  
          {open&&(
              <section className="flex flex-col gap-3 z-10 fixed right-0 top-0 h-[100vh] pt-2 pl-2 bg-neutral-500 ">
              <button onClick={()=>setOpen(false)} >  <RxCross1 /></button> 
            <ul className='flex flex-col gap-10'>
            <NavLink to={'/'} onClick={()=>setOpen(false)}><li>Home</li> </NavLink> 
            <NavLink to={'/car'}  onClick={()=>setOpen(false)}><li>Car</li></NavLink> 
            <NavLink to={'/mybooking'}   onClick={()=>setOpen(false)}> <li> Booking</li> </NavLink> 
            {/* <Button  onClick={()=>setOpen(false)}>Login</Button> */}
       <NavLink to={'/login'}   onClick={()=>setOpen(false)}> <li><Button className="bg-black text-white">login</Button></li></NavLink> 
       <NavLink to={'/signup'}  onClick={()=>setOpen(false)}> <li><Button className="bg-black text-white">Signup</Button></li></NavLink> 
            </ul>
          </section>
          )}
        
        </nav>
  }
      </header>
    )
  }

  export default Header

